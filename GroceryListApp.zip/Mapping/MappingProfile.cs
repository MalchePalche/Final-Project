﻿using AutoMapper;
using GroceryListApp.Models;

namespace GroceryListApp.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Product, Product>();
        }
    }
}
