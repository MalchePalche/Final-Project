﻿// Data/ApplicationDbContext.cs
using GroceryListApp.Models;
using Microsoft.EntityFrameworkCore;

namespace GroceryListApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Example: Setting table name
            modelBuilder.Entity<Product>().ToTable("Products");

            // Example: Setting primary key
            modelBuilder.Entity<Product>().HasKey(p => p.Id);

            // Example: Configuring properties
            modelBuilder.Entity<Product>()
                .Property(p => p.Name)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Product>()
                .Property(p => p.Price)
                .HasColumnType("decimal(18,2)");

            // Example: Seeding initial data
            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Apples", Quantity = 10, Price = 1.50m },
                new Product { Id = 2, Name = "Bananas", Quantity = 6, Price = 0.99m },
                new Product { Id = 3, Name = "Carrots", Quantity = 5, Price = 0.75m }
            );
        }
        public DbSet<Product> Products { get; set; }
    }
}
